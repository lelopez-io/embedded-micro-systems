//-----------------------------------------------------------------------------
// Title:   Technical Training Organization (TTO) BIOS Workshop 6.00
// File:	main.h 
// Rev:		1.0
// Date:	08-31-2011
// Author:	Eric Wilbur (ericw@ti.com)
// Ref:		C6748 BSL, Experimenter Test Example (audio, mcasp)
//
// Brief:	Definitions, prototypes and externs
//          Contains definitions for BUFFSIZE, DATA_SIZE, HIST_SIZE
//          for future CFIR filter and L/R channel sorting
//
// Notes:	1. Refer to main.h for key definitions
//			2. If NO GEL file present, uncomment #define in main.h
//-----------------------------------------------------------------------------

#ifndef MAIN_H_
#define MAIN_H_

//-------------------------------------------------------
// SYS/BIOS HEADER FILES
//-------------------------------------------------------
//these header files are MUSTS for the BIOS workshop labs (and most other systems)

#include <xdc/std.h>  								//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 						//mandatory - if you call APIs like BIOS_start()
#include <xdc/cfg/global.h> 						//header file for statically defined objects/handles


// sysbios kernel header files only needed if object is created dynamically.
// static sysbios objects are taken care of by the global.h file listed above.
// however, we include them here for full default coverage - in case we create dynamic objects later
// xdc runtime modules require a header file and are therefore included below


#include <ti/sysbios/knl/Clock.h> 					//when using Clock module (dynamically)
#include <ti/sysbios/knl/Idle.h>					//when using Idle (dynamically) and for Idle_run()
#include <ti/sysbios/knl/Task.h>					//when using Tasks (dynamically)
#include <ti/sysbios/knl/Semaphore.h>				//when using Semaphores (dynamically)
#include <ti/sysbios/knl/Swi.h>						//when using Idle (dyanmically)
#include <ti/sysbios/utils/Load.h>					//when using load_getCPULoad()

#include <xdc/runtime/Timestamp.h> 					//when using Timestamp APIs (TSCL/H), 32bit, 64bit
#include <xdc/runtime/System.h> 					//for runtime system calls (e.g. system_printf)
#include <xdc/runtime/Log.h>						//for Log_info() calls




//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include "stdio.h"

#include "evmomapl138.h"
#include "evmomapl138_gpio.h"
#include "evmomapl138_i2c.h"
#include "evmomapl138_mcasp.h"
#include "evmomapl138_aic3106.h"
#include "evmomapl138_led.h"



//-----------------------------------------------------------------------------
// Definitions - BUFFSIZE, PING/PONG, FILTER ORDER
//-----------------------------------------------------------------------------
#define BUFFSIZE 256
#define PING     0
#define PONG     1
#define ORDER    64


//-----------------------------------------------------------------------------
// Definitions - BUFFERS, History/Data/Hole (+ some math !)
//-----------------------------------------------------------------------------
// Declare processing buffer structure. For use with a C-coded FIR routine,
// we need a delay line on the receive buffer to keep track of the history of
// samples that are not processed, then copy them to the next incoming buffer
// in order to process them. 
//
// Each set of Rcv buffers + the history buffer are
// declared separately in order to align each on a L2 line size boundary
// (128 bytes). ORDER-1 is an odd number, so this will create holes in 
// memory. To be explicit, we have allocated space for the holes created by
// the 128-byte alignment. This has to be comprehended by the EDMA channel sorting.


#define L2_LINESIZE (128)
#define HIST_SIZE (ORDER-1)
#define DATA_SIZE (BUFFSIZE/2)


// HOLE_SIZE is based on buffer sizes and alignment. This calculation is done in
// shorts (16-bit) - hence the L2_LINESIZE/2. That is because the "hole" is defined
// as a type int16_t. Effectively, the equation is 64 - [(HIST+DATA) & (63)]. This is
// a poorman's modulo calculation.

#define HOLE_SIZE (L2_LINESIZE/2-((HIST_SIZE+DATA_SIZE) & (L2_LINESIZE/2-1)))


// BIDX_RCV_SIZE used in channel sorting to bump RCV pointer from L to R samples
#define BIDX_RCV_SIZE (HIST_SIZE + DATA_SIZE + HOLE_SIZE)


// BIDX_XMT_SIZE used in channel sorting to bump XMT pointer from L ro R samples
// This is different than BIDX_RCV_SIZE because XMT has no history or holes
#define BIDX_XMT_SIZE (DATA_SIZE)


//-----------------------------------------------------------------------------
// Buffer Structures - RCV_DATA_BUFFER (hist, data, hole), XMT_DATA_BUFFER
//-----------------------------------------------------------------------------

typedef struct rcv_data_buffer
{
	int16_t hist[HIST_SIZE];
	int16_t data[DATA_SIZE];
#if HOLE_SIZE != 0
	int16_t hole[HOLE_SIZE];
#endif
} RCV_DATA_BUFFER;


typedef struct xmt_data_buffer
{
	int16_t pingL[DATA_SIZE];
	int16_t pingR[DATA_SIZE];
	int16_t pongL[DATA_SIZE];
	int16_t pongR[DATA_SIZE];

} XMT_DATA_BUFFER;



//-----------------------------------------------------------------------------
// Prototypes
//-----------------------------------------------------------------------------
void isrAudio(void);
void init_buffers(void);
void FIR_process (void);
void McASP_Init_TTO();								
void AIC3106_Init_TTO();							
void McASP_Start_TTO();
void ledToggle();
void USTIMER_delay(uint32_t time);
void copyData(int16_t *inbuf, int16_t *outbuf, int16_t length);
void cfir(int16_t * x, int16_t * h, int16_t * restrict r, uint16_t nh, int16_t nr);



//-----------------------------------------------------------------------------
// Externs
//-----------------------------------------------------------------------------
extern RCV_DATA_BUFFER rcvPingL;
extern RCV_DATA_BUFFER rcvPingR;
extern RCV_DATA_BUFFER rcvPongL;
extern RCV_DATA_BUFFER rcvPongR;
extern XMT_DATA_BUFFER xmt;

extern	cregister volatile unsigned int	CSR;	// control status register
extern	cregister volatile unsigned int	ICR;	// interrupt clear register
extern	cregister volatile unsigned int	IER;	// interrupt enable reg.

extern uint16_t pingPong;
extern int16_t COEFFS[ORDER];


#endif






