/*
 * i2c.h
 *
 *  Created on: Dec 14, 2011
 *      Author: a0193370
 */

#ifndef I2C_H_
#define I2C_H_

#include <stdint.h>
#include <ti/sysbios/knl/Event.h>
#define EVENT_NONE Event_Id_00
#define EVENT_AL Event_Id_01
#define EVENT_NACK Event_Id_02
#define EVENT_ARDY Event_Id_03
#define EVENT_RRDY Event_Id_04
#define EVENT_XRDY Event_Id_05
#define EVENT_SCD Event_Id_06
#define EVENT_AAS Event_Id_07

#define I2C_SUCCESS 0
#define I2C_FAIL -1


/******************************************************************************
 * Function: I2C_Init
 * Inputs: none
 * Return value:  I2C_SUCCESS or I2C_FAIL
 * Description:  Set up clocks for I2C module
 *****************************************************************************/
int32_t I2C_Init();

/******************************************************************************
 * Function: I2C_Write
 * Inputs:
 *   uint16_t slaveaddr - the 7-bit (right-aligned) address of the slave device
 *                      to be written to
 *   uint8_t* data - pointer to an array of data to be written
 *   uint16_t len - the length of the data array
 * Return value:  I2C_SUCCESS or I2C_FAIL
 *****************************************************************************/
int32_t I2C_Write(uint16_t slaveaddr, uint8_t* data, uint16_t len);


/******************************************************************************
 * Function: I2C_Read
 * Inputs:
 *   uint16_t slaveaddr - the 7-bit (right-aligned) address of the slave device
 *                      to be read from
 *   uint8_t* data - pointer where the data read from the slave will be stored
 *   uint16_t len - the number of bytes to read from the slave
 * Return value:  I2C_SUCCESS or I2C_FAIL
 *****************************************************************************/
int32_t I2C_Read(uint16_t slaveaddr, uint8_t* data, uint16_t len);


/******************************************************************************
 * Function: I2C_WriteRepeatStartRead
 * Inputs:
 *   uint16_t slaveaddr - the 7-bit (right-aligned) address of the slave device
 *                      to be accessed
 *   uint8_t* write_data - pointer to the data to be written (typically a
 *                       register address in the slave)
 *   uint16_t write_len - the number of bytes to be written (often 1 or 2)
 *   uint8_t* read_data - pointer to where the data from the slave should be put
 *   uint16_t read_len - number of bytes to read from the slave
 * Return value:  I2C_SUCCESS or I2C_FAIL
 *
 * Description:  Some slave devices require a "repeat start" to be used for
 *               reading data back.  That is, first a write is performed to
 *               specify a register address within the slave.  Then, a second
 *               start condition is issue and a read is performed from that
 *               register address.  At the end of the complete sequence a
 *               STOP is issued.
 *****************************************************************************/
int32_t I2C_WriteRepeatStartRead(uint16_t slaveaddr, uint8_t* write_data, uint16_t write_len, uint8_t* read_data, uint16_t read_len);


#endif /* I2C_H_ */
