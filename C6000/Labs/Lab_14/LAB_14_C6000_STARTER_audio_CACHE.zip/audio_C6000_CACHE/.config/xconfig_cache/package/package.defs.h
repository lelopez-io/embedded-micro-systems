/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef xconfig_cache__
#define xconfig_cache__



#endif /* xconfig_cache__ */ 
