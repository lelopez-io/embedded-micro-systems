/*
 * led.c
 *
 *  Created on: Dec 14, 2011
 *      Author: a0193370
 */

#include <stdint.h>
#include "i2c_TTO.h"

/***********************************************************************/
/*                    INTERNAL MACRO DEFINITION                        */
/***********************************************************************/

/* I2C address of TCA6416 expander. */
#define I2C_SLAVE_ADDR            (0x21u)

/* Command byte to select output register. */
#define I2C_EXP_CMD_WRITE_PORT0   (0x02u)

/* Cmd to TCA6416 to configure port0. */
#define I2C_EXP_CMD_CONFIG_PORT0  (0x06u)

/* Turn on the LEDs. */
#define I2C_EXP_PORT0_LED_ON      (0x00u)

/* Turn off the LEDs. */
#define I2C_EXP_PORT0_LED_OFF     (0xc0u)

// config input/output pins (1 -> input, 0 -> output).
#define I2C_GPIO_CONFIG0_EX   (0x3F)
#define I2C_GPIO_CONFIG1_EX   (0xFF)
#define I2C_GPIO_CONFIG0_UI   (0x0F)
#define I2C_GPIO_CONFIG1_UI   (0xFF)

// TCA6416 command byte defines.
#define CMD_BYTE_INPUT0       (0x00)
#define CMD_BYTE_INPUT1       (0x01)
#define CMD_BYTE_OUTPUT0      (0x02)
#define CMD_BYTE_OUTPUT1      (0x03)
#define CMD_BYTE_POLARITY0    (0x04)
#define CMD_BYTE_POLARITY1    (0x05)
#define CMD_BYTE_CONFIG0      (0x06)
#define CMD_BYTE_CONFIG1      (0x07

void LED_init()
{
	uint8_t data[2];

	I2C_Init();

	// Configure TCA6416 CONFIG0 register such that pins 7:6 are outputs
	data[0] = CMD_BYTE_CONFIG0;
	data[1] = I2C_GPIO_CONFIG0_EX;
	I2C_Write(I2C_SLAVE_ADDR, data, 2);

	// Initialize LEDs to known state (both OFF)
	data[0] = CMD_BYTE_OUTPUT0;
	data[1] = 0xC0;
	I2C_Write(I2C_SLAVE_ADDR, data, 2);
}


// Inputs: num -- which LED (1 or 2)
void LED_toggle(uint32_t num)
{
	uint8_t data[2];

	// Initialize LEDs to known state
	// 1=OFF, 0=ON
	// BIT7 = LED1
	// BIT6 = LED2

	// Read OUTPUT0 register (will land in data[1]
	data[0] = CMD_BYTE_OUTPUT0;
	I2C_WriteRepeatStartRead(I2C_SLAVE_ADDR, data, 1, &data[1], 1);

	if (num == 0)
		data[1] ^= 0x80;
	else if (num == 1)
		data[1] ^= 0x40;

	// Write data back to OUTPUT0 register
	data[0] = CMD_BYTE_OUTPUT0;
	I2C_Write(I2C_SLAVE_ADDR, data, 2);

}
