/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z44
 */

#ifndef xconfig_hwi__
#define xconfig_hwi__



#endif /* xconfig_hwi__ */ 
