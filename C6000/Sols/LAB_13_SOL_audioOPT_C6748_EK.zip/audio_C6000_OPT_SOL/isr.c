//-----------------------------------------------------------------------------
// Title:   Technical Training Organization (TTO) BIOS Workshop 6.00
// File:	isr.c 
// Rev:		1.0
// Date:	06-10-2011
// Author:	Eric Wilbur (ericw@ti.com)
// Ref:		C6748 BSL, Experimenter Test Example (audio, mcasp)
//
// Brief:	Interrupt Service Routine, Triggered when RDATA/XDATA ready
//          Double buffered, channel sorted data on RCV/XMT
//          Most of this code could be replaced by EDMA3 transfers
//
// Notes:	1. Refer to main.h for key definitions
//			2. Refer to .cfg (INT5) properties for more info
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include "main.h"


//-----------------------------------------------------------------------------
// Defines
//-----------------------------------------------------------------------------
#define LEFT (0)
#define RIGHT (1)


//-----------------------------------------------------------------------------
// isrAudio()
//-----------------------------------------------------------------------------
#pragma FUNC_EXT_CALLED ( isrAudio );
void isrAudio(void)
{
  	static int32_t 		dataIn32, dataOut32;			//store McASP audio data
	static uint16_t 	blkCnt = 0;
	static int16_t      *pInBuf_local, *pOutBuf_local;
    static uint16_t    	leftRight = LEFT;


//Init pointers for ping/pong at beginning of new BLK only

	if (blkCnt == 0)
	{
		if (pingPong == PING)					//PING Buffers init
		{
			pInBuf_local = rcvPingL.data;		 
			pOutBuf_local  = xmt.pingL;
		}
		else 									//PONG Buffers init
		{
			pInBuf_local = rcvPongL.data;		 
			pOutBuf_local  = xmt.pongL;
		}
	}

		
//XMT data to 32-bit McASP XDATA serializer from 16-bit xmt Buffer
//Interleave data from channel sorted XMT buffer - LEFT/RIGHT.
//No shifting from hi-low half for 16-bit xfrs due to ROR bit
//being set in McASP init.
//NOTE: could be replaced by EDMA3

// RCV (RRDY) and XMT (XRDY) Interrupt Handler
//
// Note: this ISR can be triggered via an RRDY or XRDY going high. Therefore,
//       we must check to see WHICH signal triggered this ISR to run. Hence,
//       the CHKBIT calls in the code below.
//       
//       blkCnt - we only want to increment blkCnt for each L/R and XMT/RCV pair -
//                i.e. only once per 4 TIMES this ISR is called.
//
//       leftRight - is changed every other time this routine is called

	
	// Receive code
	if(CHKBIT(MCASP->SRCTL12, RRDY)) {					// if ISR triggered by RRDY...
	
		dataIn32 = MCASP->XBUF12;						// READ data from McASP Rcv XRBUF
	
		if (leftRight == LEFT) {						// RCV LEFT
			pInBuf_local[blkCnt] = (int16_t)(dataIn32);
		}
		else {											// RCV RIGHT
			pInBuf_local[ blkCnt+BIDX_RCV_SIZE ] = (int16_t)(dataIn32);
		}
	}
	
	// Transmit code
	if(CHKBIT(MCASP->SRCTL11, XRDY)) {					// if ISR triggered by XRDY...
	
		if (leftRight == LEFT) {						// XMT LEFT
			dataOut32 = pOutBuf_local[blkCnt];
		}
		else {											// XMT RIGHT
			dataOut32 = pOutBuf_local[blkCnt+BIDX_XMT_SIZE];
			
			blkCnt++;									// Increment blkCnt
		}
	
		MCASP->XBUF11 = dataOut32;						// WRITE data to McASP Xmt XBUF
		
		leftRight ^=1;									// toggle leftRight boolean
	}

	
//IF end of buffer, copy rcv-to-xmt, zero blkCnt, swap PING-PONG boolean

	if (blkCnt >= DATA_SIZE)				// if END OF CURRENT BLOCK
	{
		Semaphore_post (mcaspReadySem);		// post Semaphore to copy RCV to XMT
		pingPong ^= 1;						// swap pingPong indicator
		blkCnt = 0;				    		// zero blkCnt
	}
}


