//-----------------------------------------------------------------------------
// Title:   Technical Training Organization (TTO) BIOS Workshop 5.50
// File:	main.c 
// Rev:		1.0
// Date:	08-31-2010
// Author:	Eric Wilbur (ericw@ti.com)
// Ref:		C6748 BSL, Experimenter Test Example (audio, mcasp)
//
// Brief:	Init C6748 AIC3106/McASP via BSL calls, init buffers, CPU interrupts
//          Includes USTIMER_delay fxn that was re-written for other BSL fxns
//          LogicPD USTIMER_init() routine uses BOTH timers (TIM0, TIM1) so that
//          BIOS cannot use them. So, we nuked their routine and wrote our own
//          that is compatible with BIOS.
//
// Notes:	1. Refer to main.h for key definitions
//			2. If NO GEL file present, uncomment #define in main.h
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include "main.h"


//-----------------------------------------------------------------------------
// GLOBALS (Buffers aligned on L2_cache_line_size boundaries
//
// Note: see main.h for details of the structure
//-----------------------------------------------------------------------------

#pragma DATA_ALIGN(rcvPingL, L2_LINESIZE);
RCV_DATA_BUFFER rcvPingL; 					 

#pragma DATA_ALIGN(rcvPingR, L2_LINESIZE);
RCV_DATA_BUFFER rcvPingR;  

#pragma DATA_ALIGN(rcvPongL, L2_LINESIZE);
RCV_DATA_BUFFER rcvPongL;  

#pragma DATA_ALIGN(rcvPongR, L2_LINESIZE);
RCV_DATA_BUFFER rcvPongR;  

#pragma DATA_ALIGN(xmt, L2_LINESIZE);
XMT_DATA_BUFFER xmt;  

uint16_t pingPong;



//-----------------------------------------------------------------------------
// main()
//-----------------------------------------------------------------------------
//#pragma FUNC_EXT_CALLED ( main );

void main(void)
{

    init_buffers();								// zero buffers					

    I2C_init(I2C0, I2C_CLK_400K);				// init I2C channel
	
	LED_init();									// init LED
	
   	McASP_Init_TTO();							// init McASP (modified from original BSL)
   	AIC3106_Init_TTO();							// init AIC3106 (modified from original BSL)

	McASP_Start_TTO();							// start McASP clocks

	BIOS_start();  								// Start BIOS Scheduler
}												 



//-----------------------------------------------------------------------------
// init_buffers()
//-----------------------------------------------------------------------------

void init_buffers(void)
{
int16_t i;

// zero out delay buffers explicitly (only Rcv requires history buffers)

	for (i = 0; i < ORDER; i++)
	{
		rcvPingL.hist[i] = 0;
		rcvPingR.hist[i] = 0;
		rcvPongL.hist[i] = 0;
		rcvPongR.hist[i] = 0;
	}

// zero out data buffers explicitly (Rcv and Xmt)

	for (i = 0; i < (BUFFSIZE/2); i++)
	{
		rcvPingL.data[i] = 0;
		rcvPingR.data[i] = 0;
		rcvPongL.data[i] = 0;
		rcvPongR.data[i] = 0;

		xmt.pingL[i] = 0;
		xmt.pingR[i] = 0;
	 	xmt.pongL[i] = 0;
		xmt.pongR[i] = 0;
		
		pingPong = PING;
	}
}


//-----------------------------------------------------------------------------
// USTIMER_delay()
//
// LogicPD BSL fxn - re-written for a few BSL.c files that need it.
// The original USTIMER_init() is not used because it is NOT BIOS compatible
// and took both timers so that BIOS PRDs would not work. This is a 
// workaround.
//
// If you need a "delay" in this app, call this routine with the number
// of usec's of delay you need. It is approximate - not exact.
// value for time <300 is perfect for 1us. We padded it some.
//-----------------------------------------------------------------------------

//#pragma FUNCTION_OPTIONS(USTIMER_delay, "-o2");
void USTIMER_delay(uint32_t usec)
{
	volatile int32_t i, start, time, current;

	for (i=0; i<usec; i++)
	{
		start = Timestamp_get32();
		time = 0;
		while (time < 350)
		{
			current = Timestamp_get32();
			time = current - start;
		}
	}
}







 

