//-----------------------------------------------------------------------------
// Title:   Technical Training Organization (TTO) BIOS Workshop 5.50
// File:	fir.c 
// Rev:		1.0
// Date:	08-31-2010
// Author:	Eric Wilbur (ericw@ti.com)
// Ref:		
//
// Brief:	Data processing fxns:
//          - FIR_process - unblocked via SEM in isr.c
//                          manages pingPong switch, copies history, calls FIR
//          - cfir - performs FIR algo
//          - copyData - used to copy history from previous buf to current buf
//
// Notes:	1. Refer to main.h for key definitions
//			2. Refer to .cfg (INT5) properties for more info
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include "main.h"

//#include "dsplib64plus.h"

//void cfircopy (int16_t * Src, int16_t * Dst, int16_t len);

//-----------------------------------------------------------------------------
// FIR_process() - FIR processing fxn (copy history, then filter data)
//-----------------------------------------------------------------------------
//#pragma FUNC_EXT_CALLED ( FIR_process );
void FIR_process()
{
	volatile	int16_t temp;
	uint32_t start, finish, result, cpu_load;					// variables for benchmarking

	while(1)
	{
		Semaphore_pend(mcaspReadySem, BIOS_WAIT_FOREVER);
		
		if (pingPong == PONG)									// if PONG, filter PING
		{	

			// copy history from previous buffer
			copyData(&rcvPongL.data[DATA_SIZE - HIST_SIZE], rcvPingL.hist, HIST_SIZE);
   			copyData(&rcvPongR.data[DATA_SIZE - HIST_SIZE], rcvPingR.hist, HIST_SIZE);

			start = Timestamp_get32();  					// start time for benchmark

			// filter L and R PING channels
			cfir(rcvPingL.hist, COEFFS, xmt.pingL, ORDER, DATA_SIZE);
			cfir(rcvPingR.hist, COEFFS, xmt.pingR, ORDER, DATA_SIZE);

			finish = Timestamp_get32();						// end time for benchmark
			result = finish - start;
				
			Log_info1("FIR BENCHMARK = [%u] cycles", result);	//send benchmark to Log message
		
			cpu_load = Load_getCPULoad();					//get realtime CPU load

			Log_info1("CPU LOAD = [%u]", cpu_load); 		//send Log RTA a message (debug)			
				
				

		}
		
		else										// if PING, filter PONG
		{ 

			// copy history from previous buffer
			copyData(&rcvPingL.data[DATA_SIZE - HIST_SIZE], rcvPongL.hist, HIST_SIZE);
   			copyData(&rcvPingR.data[DATA_SIZE - HIST_SIZE], rcvPongR.hist, HIST_SIZE);

			// filter L and R PONG channels
			cfir(rcvPongL.hist, COEFFS, xmt.pongL, ORDER, DATA_SIZE);
			cfir(rcvPongR.hist, COEFFS, xmt.pongR, ORDER, DATA_SIZE);

		}

		
//		Idle_run();
	}
}


//-----------------------------------------------------------------------------
// cfir() - FIR algo 
//
// Parms:  x = delayBuffer (input Rcv buffer)
//         h = COEFFS
//         r = output Buffer (Xmt)
//		   nh = ORDER of filter
//         nr = BUFFSIZE
//
//  Brief: This is 64-order xyz-pass (depends on COEFFS) FIR filter written in C.
//
//  Note:  Can use pragma to place this code in a user_defined section. This
//         requires the addition of a user linker.cmd file. Can also incoporate
//         other optimizations as the lab instructions describe.
//
//-----------------------------------------------------------------------------
//#pragma CODE_SECTION (cfir, ".cfir");  // parameters (name_of_fxn, ".user_section_name");
//

void cfir(int16_t * x, int16_t * h, int16_t * restrict r, uint16_t nh, int16_t nr)
//void cfir(int16_t * x, int16_t * h, int16_t * r, uint16_t nh, int16_t nr)
{
   	int16_t i, j;
   	int32_t sum;


_nassert((*x & 0x7)==0);
_nassert((*h & 0x7)==0);


#pragma MUST_ITERATE(ORDER,DATA_SIZE,8);
   	for (j = 0; j < nr; j++) 
   	{
		sum = 0;
		
#pragma MUST_ITERATE(ORDER, ORDER,8);
		for (i = 0; i < nh; i++)
		sum += (int32_t)x[i + j] * h[i];

		r[j] = (int16_t)(sum >> 15);
   	}
}


//-----------------------------------------------------------------------------
// copyData() - used to copy history in FIR_process, also pass-thru
//-----------------------------------------------------------------------------
void copyData(int16_t * Src, int16_t * Dst, int16_t len)
{
 	memcpy (Dst, Src, len * sizeof(int16_t));
}






