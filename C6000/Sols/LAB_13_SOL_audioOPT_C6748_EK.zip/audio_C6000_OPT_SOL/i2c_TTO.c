/*
 * i2c.c
 *
 *  Created on: Dec 14, 2011
 *      Author: a0193370
 */

#include <stdint.h>
#include "i2c_TTO.h"

// I2C0
#define I2C_BASE        0x01c22000

/* I2C Configuration Registers */
#define I2C_OAR         (volatile uint32_t *)(I2C_BASE + 0x00)
#define I2C_IER       (volatile uint32_t *)(I2C_BASE + 0x04)
#define I2C_STR       (volatile uint32_t *)(I2C_BASE + 0x08)
#define I2C_CLKL      (volatile uint32_t *)(I2C_BASE + 0x0C)
#define I2C_CLKH      (volatile uint32_t *)(I2C_BASE + 0x10)
#define I2C_CNT       (volatile uint32_t *)(I2C_BASE + 0x14)
#define I2C_DRR       (volatile uint32_t *)(I2C_BASE + 0x18)
#define I2C_SAR       (volatile uint32_t *)(I2C_BASE + 0x1C)
#define I2C_DXR       (volatile uint32_t *)(I2C_BASE + 0x20)
#define I2C_MDR       (volatile uint32_t *)(I2C_BASE + 0x24)
#define I2C_IVR       (volatile uint32_t *)(I2C_BASE + 0x28)
#define I2C_EMDR      (volatile uint32_t *)(I2C_BASE + 0x2C)
#define I2C_PSC       (volatile uint32_t *)(I2C_BASE + 0x30)

/* I2C Field Definitions */
#define ICOAR_MASK_7         0x007F
#define ICOAR_MASK_10        0x03FF
#define ICSAR_MASK_7         0x007F
#define ICSAR_MASK_10        0x03FF
#define ICOAR_OADDR          0x007f
#define ICSAR_SADDR          0x0050

#define ICSTR_BB             0x1000
#define ICSTR_RSFULL         0x0800
#define ICSTR_XSMT           0x0400
#define ICSTR_AAS            0x0200
#define ICSTR_AD0            0x0100
#define ICSTR_ICXRDY         0x0010
#define ICSTR_ICRRDY         0x0008
#define ICSTR_ARDY           0x0004
#define ICSTR_NACK           0x0002
#define ICSTR_AL             0x0001

#define ICMDR_FREE           0x4000
#define ICMDR_STT            0x2000
#define ICMDR_IDLEEN         0x1000
#define ICMDR_STP            0x0800
#define ICMDR_MST            0x0400
#define ICMDR_TRX            0x0200
#define ICMDR_XA             0x0100
#define ICMDR_RM             0x0080
#define ICMDR_DLB            0x0040
#define ICMDR_IRS            0x0020
#define ICMDR_STB            0x0010
#define ICMDR_FDF            0x0008
#define ICMDR_BC_MASK        0x0007


/******************************************************************************
 * Function: I2C_Init
 * Inputs: none
 * Return value:  I2C_SUCCESS or I2C_FAIL
 * Description:  Set up clocks for I2C module
 *****************************************************************************/
int32_t I2C_Init()
{
  volatile int i;

  #define SYS_BASE           0x01C14000
  #define PINMUX4            *(volatile unsigned int*)(SYS_BASE + 0x130)

  // Configure PINMUX4 to bring I2C0 SCL/SDA out to pins
  PINMUX4 &= ~(0xFF00);
  PINMUX4 |= 0x2200;

  // Put I2C in reset while programming clock dividers
  *I2C_MDR = 0x0;

  /* Configure prescaler and clocks for 100 kHz operation */
  // 6748 EVM has 24 MHz input clock which feeds I2C0 module (different source for I2C1!)
  *I2C_PSC =  2;	// 24 MHz / 3 = 8 MHz prescaled clock
  //*I2C_CLKL = 40-5;	// 8 MHz / (40 + 40) = 100 kHz
  *I2C_CLKL = 10-5;	// 8 MHz / (10 + 10) = 400 kHz
  //*I2C_CLKH = 40-5;
  *I2C_CLKH = 10-5;

  return I2C_SUCCESS;
}


/******************************************************************************
 * Function: I2C_Write
 * Inputs:
 *   uint16_t slaveaddr - the 7-bit (right-aligned) address of the slave device
 *                      to be written to
 *   uint8_t* data - pointer to an array of data to be written
 *   uint16_t len - the length of the data array
 * Return value:  I2C_SUCCESS or I2C_FAIL
 *****************************************************************************/
int32_t I2C_Write(uint16_t slaveaddr, uint8_t* data, uint16_t len)
{
  uint16_t i;

  // Check for Bus Busy
  while ((*I2C_STR & ICSTR_BB));

  // Wait for MST bit to clear (indicates end of previous transaction)
  while ((*I2C_MDR & ICMDR_MST));

  /* Set the I2C controller to write len bytes */
  *I2C_CNT = len;
  *I2C_SAR = slaveaddr;
  *I2C_MDR = ICMDR_IRS | ICMDR_STT | ICMDR_STP | ICMDR_TRX | ICMDR_MST | ICMDR_FREE;

  // Transmit data
  for (i = 0; i < len; i++)
  {
	// Wait for "XRDY" flag to transmit data or "ARDY" if we get NACKed
	while ( !(*I2C_STR & (ICSTR_ICXRDY|ICSTR_ARDY)) );

	// If a NACK occurred then SCL is held low and STP bit cleared
	if ( *I2C_STR & ICSTR_NACK )
	{
		*I2C_MDR |= ICMDR_STP;	// send STP to end transfer
		*I2C_STR = ICSTR_NACK;	// clear NACK bit
		return I2C_FAIL;
	}

    *I2C_DXR = data[i];
  }

  return I2C_SUCCESS;
}

/******************************************************************************
 * Function: I2C_Read
 * Inputs:
 *   uint16_t slaveaddr - the 7-bit (right-aligned) address of the slave device
 *                      to be read from
 *   uint8_t* data - pointer where the data read from the slave will be stored
 *   uint16_t len - the number of bytes to read from the slave
 * Return value:  I2C_SUCCESS or I2C_FAIL
 *****************************************************************************/
int32_t I2C_Read(uint16_t slaveaddr, uint8_t* data, uint16_t len)
{
  uint16_t i;

  /* Check for Bus Busy */
  while ((*I2C_STR & ICSTR_BB));

  // Wait for MST bit to clear (indicates end of previous transaction)
  while ((*I2C_MDR & ICMDR_MST));

  /* Disable I2C during configuration */
  *I2C_MDR = 0;

  /* Set the I2C controller to read len bytes */
  *I2C_CNT = len;
  *I2C_SAR = slaveaddr;
  *I2C_MDR = ICMDR_IRS | ICMDR_STT | ICMDR_STP | ICMDR_MST | ICMDR_FREE;

  /* Receive data */
  for (i = 0; i < len; i++)
  {
	// Wait for I2C to read data or get NACKed
	while( !(*I2C_STR & (ICSTR_ICRRDY|ICSTR_ARDY)) );

	// If a NACK occurred then SCL is held low and STP bit cleared
	if ( *I2C_STR & ICSTR_NACK )
	{
			*I2C_MDR |= ICMDR_STP;	// send STP to end transfer
			*I2C_STR = ICSTR_NACK;	// clear NACK bit
			return I2C_FAIL;
	}

	// Make sure that you got the RRDY signal
	while( !(*I2C_STR & ICSTR_ICRRDY) ) {};

	data[i] = *I2C_DRR;
  }

  return I2C_SUCCESS;
}

/******************************************************************************
 * Function: I2C_WriteRepeatStartRead
 * Inputs:
 *   uint16_t slaveaddr - the 7-bit (right-aligned) address of the slave device
 *                      to be accessed
 *   uint8_t* write_data - pointer to the data to be written (typically a
 *                       register address in the slave)
 *   uint16_t write_len - the number of bytes to be written (often 1 or 2)
 *   uint8_t* read_data - pointer to where the data from the slave should be put
 *   uint16_t read_len - number of bytes to read from the slave
 * Return value:  I2C_SUCCESS or I2C_FAIL
 *
 * Description:  Some slave devices require a "repeat start" to be used for
 *               reading data back.  That is, first a write is performed to
 *               specify a register address within the slave.  Then, a second
 *               start condition is issue and a read is performed from that
 *               register address.  At the end of the complete sequence a
 *               STOP is issued.
 *****************************************************************************/
int32_t I2C_WriteRepeatStartRead(uint16_t slaveaddr, uint8_t* write_data, uint16_t write_len, uint8_t* read_data, uint16_t read_len)
{
  uint16_t i;

  /* Check for Bus Busy */
  while ((*I2C_STR & ICSTR_BB));

  // Wait for MST bit to clear (indicates end of previous transaction)
  while ((*I2C_MDR & ICMDR_MST));

  /* Disable I2C during configuration */
  *I2C_MDR = 0;

  /* Set the I2C controller to write len bytes */
  *I2C_CNT = write_len;
  *I2C_SAR = slaveaddr;
  *I2C_MDR = ICMDR_IRS | ICMDR_STT | ICMDR_TRX | ICMDR_MST | ICMDR_FREE;

  /* Transmit data */
  for (i = 0; i < write_len; i++)
  {
	// Wait for "XRDY" flag to transmit data or "ARDY" if we get NACKed
	while ( !(*I2C_STR & (ICSTR_ICXRDY|ICSTR_ARDY)) );

	// If a NACK occurred then SCL is held low and STP bit cleared
	if ( *I2C_STR & ICSTR_NACK )
	{
			*I2C_MDR |= ICMDR_STP;	// send STP to end transfer
			*I2C_STR = ICSTR_NACK;	// clear NACK bit
			return I2C_FAIL;
	}

    *I2C_DXR = write_data[i];
  }

  // wait for ARDY before beginning the read phase of the transaction
  while ( !(*I2C_STR & ICSTR_ARDY) );

  /* Set the I2C controller to read len bytes */
  *I2C_CNT = read_len;
  *I2C_MDR = ICMDR_IRS | ICMDR_STT | ICMDR_STP | ICMDR_MST | ICMDR_FREE;

  /* Receive data */
  for (i = 0; i < read_len; i++)
  {
	// Wait for I2C to read data or or "ARDY" if we get NACKed
	while( !(*I2C_STR & (ICSTR_ICRRDY|ICSTR_ARDY)) ) {};

	// If a NACK occurred then SCL is held low and STP bit cleared
	if ( *I2C_STR & ICSTR_NACK )
	{
			*I2C_MDR |= ICMDR_STP;	// send STP to end transfer
			*I2C_STR = ICSTR_NACK;	// clear NACK bit
			return I2C_FAIL;
	}

	// Make sure that you got the RRDY signal
	while( !(*I2C_STR & ICSTR_ICRRDY) ) {};

	read_data[i] = *I2C_DRR;
  }

  return I2C_SUCCESS;
}


