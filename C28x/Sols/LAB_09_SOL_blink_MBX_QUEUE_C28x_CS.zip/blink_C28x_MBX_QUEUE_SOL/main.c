//----------------------------------------------------------------------------------
// Project: Blink C28x Using BIOS Mailbox-Queue (SOLUTION-QUEUE)
// Author: Eric Wilbur
// Date: June 2014
//
// Note: The following files are NOT needed when using BIOS:
//		 F2806x_PieCtrl.c, F2806x_PieVect.c, F2806x_DefaultIsr.c
//
//       BIOS takes care of all vector and ISR management
//       Read the EWareReadme.txt file for more details on this.
//
// Follow these steps to create this project in CCSv6.0:
// 1. Project -> New CCS Project
// 2. Select Template:
//    - TI-RTOS for C2000 -> Kernel Examples -> TI Target Ex -> Minimal ->
//    - this template does NOT contain ControlSuite or UIA/RTOS Analyzer support
// 3. Add UIA from available products
// 4. Add EWare_F28069_BIOS to project
// 5. Add F2806x_Headers_BIOS.cmd
// 6. Add main.c from TI-RTOS Workshop Solution file for this lab
// 7. Edit as needed (to add/subtract) BIOS services, delete given Task
// 8. Add include search paths (two of them from _headers and _common)
// 9. Build, load, run...
//
// FYI - Part B solution for Queues is actually shown working. Part A solution
// (Mailbox) is populated below but commented out.
//------------------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  								//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 						//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>						//for Log_info() calls when UIA is added
#include <xdc/cfg/global.h> 						//header file for statically defined objects/handles


//-----------------------------------------
// ControlSuite Header Files
//-----------------------------------------
#include "DSP28x_Project.h"


//-----------------------------------------
// Prototypes
//-----------------------------------------
void hardware_init(void);
void ledToggle(void);
void Timer_ISR(void);


//-----------------------------------------
// Globals
//-----------------------------------------
volatile int16_t i16ToggleCount = 0;

//------------------------
// for Mailbox - Part A
//------------------------
//typedef struct MsgObj {
//	Int	val;            		// message value
//} MsgObj, *Msg;				// Message object and pointer type


//------------------------
// for Queue - Part B
//------------------------
typedef struct MsgObj {
	Queue_Elem	elem;
	Int	val;            		// message value
} MsgObj, *Msg;					// Use Msg as pointer to MsgObj



//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();				// init hardware via Xware

   BIOS_start();				// Start BIOS Scheduler

}


//-----------------------------------------------------------------------------
// hardware_init()
//-----------------------------------------------------------------------------
void hardware_init(void)					//called by main
{

// Init PLL, watchdog, periph clocks - see F2806x_SysCtrl.c file
// Clock frequency set to 90 MHz - see F2806x_Examples.h
	InitSysCtrl();

// Copy InitFlash fxn to RAM and run it - sets flash wait states for 90MHz
	memcpy(&RamfuncsRunStart,&RamfuncsLoadStart,(unsigned long)&RamfuncsLoadSize);
	InitFlash();

// Configure GPIO34 (LD2 LED2 of Control Stick) as a GPIO output pin
	EALLOW;
	GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;
	GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;
	EDIS;

// Init CPU Timers - see F2806x_CpuTimers.c for the fxn
	InitCpuTimers();

// Configure CPU-Timer 0 to interrupt every 500 milliseconds
// 90MHz CPU Freq, 500ms period (in uSec)
	ConfigCpuTimer(&CpuTimer0, 90, 500000);

// Start CPU Timer 0
	CpuTimer0Regs.TCR.all = 0x4001;

}


//---------------------------------------------------------------------------
// mailbox_queue Task() - Run by BIOS_Start(), then unblocked by Timer ISR
//
// Places state of LED (msg.val) into a mailbox for ledToggle() to use
//---------------------------------------------------------------------------
void mailbox_queue(void)
{

//---------------------------------
// msg used for Mailbox and Queue
//---------------------------------
	MsgObj msg;													// create an instance of MsgObj named msg

//---------------------------------
// msgp used for Queue only
//---------------------------------
	Msg msgp;													// Queues pass POINTERS, so we need a pointer of type Msg
	msgp = &msg;												// init message pointer to address of msg


	msg.val = 1;												// set initial value of msg.val (LED state)

	while(1){

		msg.val ^= 1;											// toggle msg.val (LED state)

		Semaphore_pend(mailbox_queue_Sem, BIOS_WAIT_FOREVER);	// wait on semaphore from Timer ISR

//------------------------------
// MAILBOX CODE follows...
//------------------------------
//		Mailbox_post (LED_Mbx, &msg, BIOS_WAIT_FOREVER);		// post msg containing LED state into the MAILBOX


//------------------------------
// QUEUE CODE follows...
//------------------------------
		Queue_put(LED_Queue, (Queue_Elem*)msgp);				// pass pointer to Message object via LED_Queue
		Semaphore_post (QueSem);								// unblock Queue_get to get msg

	}

}



//---------------------------------------------------------------------------
// ledToggle()  - called by BIOS_Start(), then unblocked by mailbox_queue()
//
// Toggle LED via GPIO pin (LD2 on 28069 Control Stick)
//---------------------------------------------------------------------------
void ledToggle(void)
{

//---------------------------------
// msg used for Mailbox and Queue
//---------------------------------
	MsgObj msg;													//define msg using MsgObj struct created earlier

//---------------------------------
// msgp used for Queue only
//---------------------------------
	Msg msgp;													//define pointer to MsgObj to use with queue put/get
	msgp = &msg;												//init msgp to point to address of msg (used for put/get)


	while(1)
	{


//------------------------------
// MAILBOX CODE follows...
//------------------------------
//		Mailbox_pend(LED_Mbx, &msg, BIOS_WAIT_FOREVER);			// wait/block until post of msg, get msg.val


//------------------------------
// QUEUE CODE follows...
//------------------------------
		Semaphore_pend(QueSem, BIOS_WAIT_FOREVER);				// unblocked by mailbox_queue() when Queue has msg
		msgp = Queue_get(LED_Queue);							// read contents of queue to get value of LED state



//		if (msg.val)											// MAILBOX "if" - msg.val contains LED state

		if(msgp->val)											// QUEUE "if" - mspg->val contains LED state for QUEUE's the use pointers

		{
			GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;				// turn ON LED using "CLEAR" (0 = ON)
		}
		else
		{
			GpioDataRegs.GPBSET.bit.GPIO34 = 1; 				// turn OFF LED using "SET" (1 = OFF)
		}

		i16ToggleCount += 1;									// keep track of #toggles

		Log_info1("LED TOGGLED [%u] TIMES",i16ToggleCount);

	}
}


//---------------------------------------------------------------------------
// Timer ISR - called by BIOS Hwi (see app.cfg)
//
// Posts Swi to toggle the LED
//---------------------------------------------------------------------------
void Timer_ISR(void)
{
	Semaphore_post(mailbox_queue_Sem);							// post mailbox_queue_sem to write unblock mailbox-queue Task

}



