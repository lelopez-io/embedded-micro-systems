//----------------------------------------------------------------------------------
// Project: Blink C28x Using BIOS Clock Fxns (STARTER)
// Author: Eric Wilbur
// Date: June 2014
//
// Note: The following files are NOT needed when using BIOS:
//		 F2806x_PieCtrl.c, F2806x_PieVect.c, F2806x_DefaultIsr.c
//
//       BIOS takes care of all vector and ISR management
//       Read the EWareReadme.txt file for more details on this.
//
// Follow these steps to create this project in CCSv6.0:
// 1. Project -> New CCS Project
// 2. Select Template:
//    - TI-RTOS for C2000 -> Kernel Examples -> TI Target Ex -> Minimal ->
//    - this template does NOT contain ControlSuite or UIA/RTOS Analyzer support
// 3. Add UIA from available products
// 4. Add EWare_F28069_BIOS to project
// 5. Add F2806x_Headers_BIOS.cmd
// 6. Add main.c from TI-RTOS Workshop Solution file for this lab
// 7. Edit as needed (to add/subtract) BIOS services, delete given Task
// 8. Add include search paths (two of them from _headers and _common)
// 9. Build, load, run...
//------------------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						// mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				// mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>				// for Log_info() calls when UIA is added
#include <xdc/cfg/global.h> 				// header file for statically defined objects/handles
#include <xdc/runtime/Timestamp.h>			// used for Timestamp() calls


//-----------------------------------------
// ControlSuite Header Files
//-----------------------------------------
#include "DSP28x_Project.h"


//-----------------------------------------
// Prototypes
//-----------------------------------------
void hardware_init(void);
void ledToggle(void);
void Timer_ISR(void);


//-----------------------------------------
// Globals
//-----------------------------------------
volatile int16_t i16ToggleCount = 0;


//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();							// Start BIOS Scheduler

}


//-----------------------------------------------------------------------------
// hardware_init()
//-----------------------------------------------------------------------------
void hardware_init(void)					//called by main
{

// Init PLL, watchdog, periph clocks - see F2806x_SysCtrl.c file
// Clock frequency set to 90 MHz - see F2806x_Examples.h
	InitSysCtrl();

// Copy InitFlash fxn to RAM and run it - sets flash wait states for 90MHz
	memcpy(&RamfuncsRunStart,&RamfuncsLoadStart,(unsigned long)&RamfuncsLoadSize);
	InitFlash();

// Configure GPIO34 (LD2 LED2 of Control Stick) as a GPIO output pin
	EALLOW;
	GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;
	GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;
	EDIS;

// Init CPU Timers - see F2806x_CpuTimers.c for the fxn
	InitCpuTimers();

// Configure CPU-Timer 0 to interrupt every 500 milliseconds
// 90MHz CPU Freq, 500ms period (in uSec)
	ConfigCpuTimer(&CpuTimer0, 90, 500000);

// Start CPU Timer 0
	CpuTimer0Regs.TCR.all = 0x4001;

}


//---------------------------------------------------------------------------
// ledToggle() ISR - called by BIOS Hwi (see app.cfg)
//
// Toggle LED via GPIO pin (LD2 on 28069 Control Stick)
//---------------------------------------------------------------------------
void ledToggle(void)
{
	static uint32_t ui32_t0, ui32_t1, ui32_t2, ui32start, ui32stop, ui32delta;

	ui32_t0 = Timestamp_get32();						// calculate Timestamp() overhead (ui32_t2)
	ui32_t1 = Timestamp_get32();
	ui32_t2 = ui32_t1 - ui32_t0;

	ui32start = Timestamp_get32();						// get starting Timer snapshot for LED benchmark

	GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1; 				// Toggle GPIO34 (LD2) of Control Stick

	ui32stop = Timestamp_get32();						// get ending Timer snapshot for LED benchmark

	ui32delta = ui32stop - ui32start - ui32_t2;			// calculate LED toggle benchmark


	i16ToggleCount += 1;										// keep track of #toggles

	Log_info1("LED TOGGLED [%u] TIMES", i16ToggleCount);		// send #toggles to Log display

	Log_info1("LED BENCHMARK = [%u] C28x CYCLES", ui32delta);	// send LED benchmark to Log display

}


//---------------------------------------------------------------------------
// Timer ISR - called by BIOS Hwi (see app.cfg)
//
// Posts Swi (or later a Task) to toggle the LED
//---------------------------------------------------------------------------
void Timer_ISR(void)
{
	Swi_post(LEDSwi);
}



