//--------------------------------------------------------------
//
// Main.c - Benchmark BIOS vs. NON-BIOS Mg'd Interrupts
//
// Author: Eric Wilbur 12/18/13
//
// Interrupt #50 used for BIOS-Mg'd interrupt
// Interrupt #51 used for non-BIOS Mg'd interrupt (Zero latency)
//--------------------------------------------------------------

//---------------------------------------
// BIOS Header Files first
//---------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles
#include <xdc/runtime/Log.h>				//used for Log_info() calls
#include <xdc/runtime/System.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>
#include <string.h>
#include <xdc/runtime/Error.h>


//---------------------------------------
// Prototypes
//---------------------------------------
void isr_BIOS(UArg a0);
void interrupt isr_nonBIOS ();
void taskFxn (UArg a0, UArg a1);


//---------------------------------------
// Globals
//---------------------------------------
UInt32 t0, t1;
UInt32 timestamp_overhead, bios_isr_snapshot, nonbios_isr_snapshot;
UInt32 bios_start_snapshot, nonbios_start_snapshot, bios_int_latency, nonbios_int_latency;


//---------------------------------------
// taskFxn - triggered by BIOS_Start
// Triggers ISRs and performs benchmarks
//---------------------------------------
Void taskFxn(UArg a0, UArg a1)
{

	// determine Timestamp overvead:
	t0 = Timestamp_get32();
	t1 = Timestamp_get32();
	timestamp_overhead = t1 - t0;

	// determine BIOS-Mg'd interrupt latency
	bios_start_snapshot = Timestamp_get32();
	Hwi_post(50);   												// post BIOS-mg'd interrupt (50)
	bios_int_latency = bios_isr_snapshot - bios_start_snapshot - timestamp_overhead;

	
	// determine NON-BIOS-Mg'd interrupt latency
	nonbios_start_snapshot = Timestamp_get32();
	Hwi_post(51);   												// trigger non-BIOS Managed interrupt (51)
	nonbios_int_latency = nonbios_isr_snapshot - nonbios_start_snapshot - timestamp_overhead;

	// print results to Console screen
	System_printf("TIMESTAMP FXN OVERHEAD = %d CYCLES\n", timestamp_overhead);
	System_printf("Tiva-C BIOS Interrupt Latency = %d CYCLES\n", bios_int_latency);
	System_printf("Tiva-C Zero Latency Interrupt Latency = %d CYCLES\n", nonbios_int_latency);
	System_flush();

	// falls into Idle loop here - forever.
}

void isr_BIOS(UArg a0)
{
	bios_isr_snapshot = Timestamp_get32();
}

void interrupt isr_nonBIOS()
{
	nonbios_isr_snapshot = Timestamp_get32();
}

//---------------------------------------
// main()
// Simply starts BIOS, then task runs
// and triggers the ISRs
//---------------------------------------
Int main()
{ 
    BIOS_start();    /* does not return */
    return(0);
}
