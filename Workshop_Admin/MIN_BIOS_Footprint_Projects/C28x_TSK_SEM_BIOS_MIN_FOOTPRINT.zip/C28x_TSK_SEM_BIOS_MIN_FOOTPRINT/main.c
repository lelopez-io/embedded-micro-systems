//---------------------------------------------------------------------------
// Project: Blink C28x BIOS (using Idle)
// Author: Eric Wilbur
// Date: Aug 2013
//
// Note: The following files are NOT needed when using BIOS:
//		 F2806x_PieCtrl.c, F2806x_PieVect.c, F2806x_DefaultIsr.c
//		 These files excluded with "ti_sysbios_BIOS__include" defined by
//       BIOS. Also, other files have partial exclusions based on this
//       symbol
//
//       BIOS takes care of all vector and ISR management
//
// Note: Other than the std include search paths required for the header files,
//       users must add "xdc__strict" as a PreDefined Symbol in Properties or
//       else you will get build errors. See the lab instructions for more
//       details.
//
// Note: See EWareReadme.txt for more details
//
//---------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>				//for Log_info() calls when UIA is added
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles


//-----------------------------------------
// ControlSuite Header Files
//-----------------------------------------
#include "DSP28x_Project.h"


//-----------------------------------------
// Prototypes
//-----------------------------------------
void hardware_init(void);
void ledToggle(void);
void delay(void);


//-----------------------------------------
// Globals
//-----------------------------------------
volatile int16_t i16ToggleCount = 0;


//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();							// Start BIOS Scheduler

}


//-----------------------------------------------------------------------------
// hardware_init()
//-----------------------------------------------------------------------------
void hardware_init(void)					//called by main
{

// Init PLL, watchdog, periph clocks - see F2806x_SysCtrl.c file
// Clock frequency set to 90 MHz - see F2806x_Examples.h
	InitSysCtrl();

// Configure GPIO34 (LD2 LED2 of Control Stick) as a GPIO output pin
	EALLOW;
	GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;
	GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;
	EDIS;

	Semaphore_post(mySem);
}


//---------------------------------------------------------------------------
// ledToggle()
//
// Toggle LED via GPIO pin (LD2 on 28069 Control Stick)
//---------------------------------------------------------------------------
void ledToggle(void)
{

	Semaphore_pend(mySem, BIOS_WAIT_FOREVER);

	GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1; 		// Toggle GPIO34 (LD2) of Control Stick

	delay();									// create a delay of ~1/2sec

	i16ToggleCount += 1;						// keep track of #toggles

	Log_info1("LED TOGGLED [%u] TIMES",i16ToggleCount);

}


//-----------------------------------------------------------------------------
// delay()
//
// Note: DELAY_US(time) does work in this lab, but conflicts w/BIOS in the
//       next lab, so we're just using a dumb for() loop  ;-)
//-----------------------------------------------------------------------------
void delay(void)								//called by main
{
	uint32_t u32i;

	for (u32i=0; u32i<700000; u32i++);			//delay ~1/2sec

}






