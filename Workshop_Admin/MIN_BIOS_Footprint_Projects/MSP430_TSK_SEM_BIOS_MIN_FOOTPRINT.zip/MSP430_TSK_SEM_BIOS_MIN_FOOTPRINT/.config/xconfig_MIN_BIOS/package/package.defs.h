/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef xconfig_MIN_BIOS__
#define xconfig_MIN_BIOS__



#endif /* xconfig_MIN_BIOS__ */ 
