/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef xconfig_MIN_BIOS_KW__
#define xconfig_MIN_BIOS_KW__



#endif /* xconfig_MIN_BIOS_KW__ */ 
