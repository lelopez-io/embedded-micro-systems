TI-RTOS workshop EWareReadme.txt for C28x Users of BIOS
Author: Eric Wilbur


Where did EWare come from?

EWare is what the workshop author called his subset of header files needed to create
the labs. EWare is "Extracted" Ware - the author's play on the Wares out there. The original
files came from the standard controlSUITE install at these locations:

C:\TI\controlSUITE\device_support\f2806x\v136\F2806x_common\source
C:\TI\controlSUITE\device_support\f2806x\v136\F2806x_headers\source

All C28x programmers will end up using a subset of header file code depending on what their
application needs. This implementation is no different.

The files contained in the EWare folder are the only files necessary to perform the labs
in this workshop. However, when BIOS is added to the current header file code, there are
conflicts in the interrupts and timers areas. In all BIOS labs, the author excludes parts
of these files with the symbol "BIOS" defined at the top of these files. If BIOS is present in the
program, this symbol is activated and therefore the author used this symbol for exclusions of
code or files that conflict with BIOS.

For non-BIOS programs, all files in EWare are used. 

For BIOS programs, the following files are excluded. These
files have code that conflicts with BIOS' implementation and are therefore excluded:
	F2806x_PieCtrl.c
	F2806x_PieVect.c
	F2806x_DefaultIsr.c
	
For BIOS programs, the following FILE has code exclusions using the symbol "BIOS".
The use of Timer 1 and Timer 2 conflict with BIOS. Timer 0 is left alone:
	F2806x_CpuTimers.c


*** END ***
