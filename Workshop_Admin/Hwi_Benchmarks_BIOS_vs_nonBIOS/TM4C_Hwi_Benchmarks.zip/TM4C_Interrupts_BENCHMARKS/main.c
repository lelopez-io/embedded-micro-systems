//-------------------------------------------------------------------------------------------------
//
// Main.c - TM4C Benchmark BIOS vs. NON-BIOS Mg'd Interrupts
//
// Author: Eric Wilbur 01/06/13
//
// Interrupt #50 used for BIOS-Managed interrupt
// Interrupt #51 used for NON-BIOS-Managed Interrupt
//
// Task is used because Tasks are ready when they are created (during BIOS_init, before main())
// and therefore they require no "trigger" to run.
//
// Interrupt #50 is managed by BIOS and therefore can be found in app.cfg GUI (priority group 7)
// Interrupt #51 is NOT managed by BIOS, but can still be found in the app.cfg GUI (priority group 0)
//
// For M4 processors, BIOS sets the default "don't mess with these" priority level to 1.
// Therefore any interrupts in priority groups 1-7 will be managed by BIOS. Any interrupts
// in priority group ZERO (0) will NOT be managed by BIOS. These are referred to as
// "zero latency" interrupts even though their latency is greater than zero.
//
// When task runs:
// - The timestamp benchmark is taken (i.e. how long Timestamp_get32 take - Timestamp overhead)
// - BIOS managed interrupt (INT #50) is triggered and benchmark is taken
// - Non-bios managed interrupt (INT #51) is triggered and benchmark is taken
// - Results are printed to the console screen via System_printf()
//
// FYI - Hwi_post() is supported on the TM4C processors and therefore is used to trigger
// each interrupt.
//
// Note that the boot module in the app.cfg file is set to 40MHz. Flash wait states do have an
// effect on the cycle count for this benchmark. If you run at, e.g. 80MHz, your results may
// be different. However, the cycle counts shown can be used as an estimate for any project
// using any frequency.
//
// TO RUN THIS CODE:
//
// Build, load and press Play (Resume). Watch the console window where the results will be
// displayed. You can then tweak the Hwi instance or anything else you'd like to see how
// those changes affect the benchmark.
//
// CONCLUSION:
//
// BIOS will set certain features on by default for all interrupts. This is the "DEFAULT" benchmark
// shown below. However, with ALL of the features turned off (which is not desirable), you can see
// the "MIN BIOS" benchmark below. The "ZERO LATENCY" benchmark is the latency of the interrupt
// without BIOS involvement at all.
//
// To obtain the BIOS (MIN) benchmark, simply go into the app.cfg GUI and click on the instance
// and the module for Hwi and UNCHECK every box you see. Again, this is probably not desirable
// for most applications - but hey, it's a benchmark and you know how we obtained it.
//
// The latency numbers shown below are from the approximate time of the trigger to the first line
// of code in the ISR. All numbers are approximate and your mileage may vary.
//
// TM4C Interrupt Latency Results running at 40MHz using TM4C123G Launchpad:
//
// BIOS (DEFAULT): 114 cycles
// BIOS (MIN):     101 cycles
// ZERO-LATENCY:    25 cycles
//---------------------------------------------------------------------------------------------------


//---------------------------------------
// BIOS Header Files first
//---------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles
#include <xdc/runtime/Log.h>				//used for Log_info() calls
#include <xdc/runtime/System.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>
#include <string.h>
#include <xdc/runtime/Error.h>


//---------------------------------------
// Prototypes
//---------------------------------------
void isr_BIOS(UArg a0);
void interrupt isr_nonBIOS ();
void taskFxn (UArg a0, UArg a1);
void hardware_init(void);


//---------------------------------------
// Globals
//---------------------------------------
UInt32 t0, t1, timestamp_overhead;
UInt32 bios_isr_start, bios_isr_end;
UInt32 nonbios_isr_start, nonbios_isr_end;
UInt32 bios_int_latency, nonbios_int_latency;



//--------------------------------------------------------------
// taskFxn()
//
// Triggered by BIOS_Start()
// Triggers ISRs and performs benchmarks, then prints them
// to the console screen
//--------------------------------------------------------------
Void taskFxn(UArg a0, UArg a1)
{

	t0 =  Timestamp_get32();							// determine Timestamp overhead
	t1 =  Timestamp_get32();
	timestamp_overhead = t1 - t0;

	bios_isr_start = Timestamp_get32();					// start BIOS-managed interrupt snapshot
	Hwi_post(50);										// post BIOS-managed INT (47)

	nonbios_isr_start = Timestamp_get32();				// start non-BIOS-managed interrupt snapshot
	Hwi_post(51);  									// post non-BIOS-managed INT (42)

	// Calculate interrupt latencies
	bios_int_latency =  bios_isr_end -  bios_isr_start -  timestamp_overhead;
	nonbios_int_latency = nonbios_isr_end - nonbios_isr_start - timestamp_overhead;

	// print results to Console screen
	System_printf("TIMESTAMP FXN OVERHEAD = [%u] CYCLES\n", timestamp_overhead);
	System_printf("TM4C BIOS Interrupt Latency = [%u] CYCLES\n", bios_int_latency);
	System_printf("TM4C Zero Latency Interrupt Latency = [%u] CYCLES\n", nonbios_int_latency);
	System_flush();

	// falls into Idle loop here - forever.
}


//---------------------------------------------------------------
// isr_BIOS()
//
// Vector plugged by BIOS app.cfg - INT #50 (priority group 7)
// BIOS interrupt does NOT use interrupt keyword
//
// Take snapshot of Timestamp timer and then return
//---------------------------------------------------------------
void isr_BIOS(UArg a0)
{
	bios_isr_end = Timestamp_get32();			// take snapshot of timer
}


//------------------------------------------------------------------
// isr_nonBIOS()
//
// Vector plugged by BIOS app.cfg - INT #51 (priority group 0)
// Non-bios interrupt uses interrupt keyword
//
// Take snapshot of Timestamp timer and then return
//------------------------------------------------------------------
void interrupt isr_nonBIOS()
{
	nonbios_isr_end = Timestamp_get32();		// take snapshot of timer
}



//----------------------------------------------------------------------
// main()
//
// Call hardware_init() to perform hardware setup for this architecture
// Then call BIOS_start()
// Note:  as soon as BIOS_start() begins, it will run the taskFxn above
//----------------------------------------------------------------------
void main(void) {

	hardware_init();	// target-specific hardware setup

	BIOS_start();    	// does not return
}



//------------------------------------------------------------------------
// hardware_init()
//
// for TM4C, no actions are required
//------------------------------------------------------------------------
void hardware_init(void) {

// no actions required for this architecture

}

