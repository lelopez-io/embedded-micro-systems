//-------------------------------------------------------------------------------------------------
//
// Main.c - MSP430 Benchmark BIOS vs. NON-BIOS Mg'd Interrupts
//
// Author: Eric Wilbur 01/06/13
//
// Interrupt #47 (GPIO Port 1 Interrupt) used for BIOS-Managed interrupt
// Interrupt #42 (GPIO Port 2 Interrupt) used for NON-BIOS-Managed Interrupt
//
// Task is used because Tasks are ready when they are created (during BIOS_init, before main())
// and therefore they require no "trigger" to run.
//
// Interrupt #47 is managed by BIOS and therefore can be found in app.cfg GUI
// Interrupt #42 is PLUGGED via the #pragma shown below just above the isr_nonBIOS() fxn
//
// When task runs:
// - The timestamp benchmark is taken (i.e. how long Timestamp_get32 take - Timestamp overhead)
// - BIOS managed interrupt (INT #47) is triggered and benchmark is taken
// - Non-bios managed interrupt (INT #42) is triggered and benchmark is taken
// - Results are printed to the console screen via System_printf()
//
// FYI - Hwi_post() is NOT supported on the MSP430. Therefore a "poke" of the IFG register
// e.g. P1IFG = 0x02 is used to trigger the interrupt
//
// Note that, by default, BIOS will set the CPU frequency to 8.192MHz. This frequency
// is not changed in the code. However, when using Timestamp_get32(), the default timer
// used is ACLK which runs at 32KHz. Bad idea. If you click on the Timestamp module in the
// GUI, you will see that the author changed the timer to use SMCLK instead to provide
// better accuracy. This is covered in lab 7 of the TI-RTOS kernel workshop.
//
// TO RUN THIS CODE:
//
// Build, load and press Play (Resume). Watch the console window where the results will be
// displayed. You can then tweak the Hwi instance or anything else you'd like to see how
// those changes affect the benchmark.
//
// CONCLUSION:
//
// BIOS will set certain features on by default for all interrupts. This is the "DEFAULT" benchmark
// shown below. However, with ALL of the features turned off (which is not desirable), you can see
// the "MIN BIOS" benchmark below. The "ZERO LATENCY" benchmark is the latency of the interrupt
// without BIOS involvement at all.
//
// To obtain the BIOS (MIN) benchmark, simply go into the app.cfg GUI and click on the instance
// and the module for Hwi and UNCHECK every box you see. Again, this is probably not desirable
// for most applications - but hey, it's a benchmark and you know how we obtained it.
//
// The latency numbers shown below are from the approximate time of the trigger to the first line
// of code in the ISR. All numbers are approximate and your mileage may vary.
//
// MSP430 Interrupt Latency Results running at 8.192MHz using MSP430-5529 Launchpad:
//
// BIOS (DEFAULT): 96 cycles
// BIOS (MIN):     32 cycles
// ZERO-LATENCY:   25 cycles
//---------------------------------------------------------------------------------------------------



//---------------------------------------
// BIOS Header Files first
//---------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles
#include <xdc/runtime/Log.h>				//used for Log_info() calls
#include <xdc/runtime/System.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>
#include <string.h>
#include <xdc/runtime/Error.h>


//--------------------------------------------
// MSP430 Driver Library Header Files
//--------------------------------------------
#include <driverlib.h>



//---------------------------------------
// Prototypes
//---------------------------------------
void isr_BIOS(void);
void interrupt isr_nonBIOS (void);
void taskFxn (UArg a0, UArg a1);
void hardware_init(void);



//---------------------------------------
// Globals
//---------------------------------------
UInt32 t0, t1, timestamp_overhead;
UInt32 bios_isr_start, bios_isr_end;
UInt32 nonbios_isr_start, nonbios_isr_end;
UInt32 bios_int_latency, nonbios_int_latency;



//--------------------------------------------------------------
// taskFxn()
//
// Triggered by BIOS_Start()
// Triggers ISRs and performs benchmarks, then prints them
// to the console screen
//--------------------------------------------------------------
Void taskFxn(UArg a0, UArg a1)
{

	t0 =  Timestamp_get32();						// determine Timestamp overhead
	t1 =  Timestamp_get32();
	timestamp_overhead = t1 - t0;

	bios_isr_start = Timestamp_get32();				// start BIOS-managed interrupt snapshot
	P1IFG = 0x02;									// post BIOS-mg'd interrupt on PORT 1 (47)

	nonbios_isr_start = Timestamp_get32();			// start non-BIOS-managed interrupt snapshot
	P2IFG = 0x02;  									// post non-BIOS-managed interrupt on PORT 2 (42)

	// Calculate interrupt latencies
	bios_int_latency =  bios_isr_end -  bios_isr_start -  timestamp_overhead;
	nonbios_int_latency = nonbios_isr_end - nonbios_isr_start - timestamp_overhead;

	// print results to Console screen
	System_printf("TIMESTAMP FXN OVERHEAD = [%u] CYCLES\n", timestamp_overhead);
	System_printf("MSP430 BIOS Interrupt Latency = [%u] CYCLES\n", bios_int_latency);
	System_printf("MSP430 Zero Latency Interrupt Latency = [%u] CYCLES\n", nonbios_int_latency);
	System_flush();

	// falls into Idle loop here - forever.
}



//---------------------------------------------------------------
// isr_BIOS()
//
// Vector plugged by BIOS app.cfg - port 1, INT 47
// BIOS interrupt does NOT use interrupt keyword
//
// Take snapshot of Timestamp timer and then clear IFG register
//---------------------------------------------------------------
void isr_BIOS(void)
{
	bios_isr_end = Timestamp_get32();			// take snapshot of timer

	P1IFG = 0;									// clear P1IFG register
}



//------------------------------------------------------------------
// isr_nonBIOS()
//
// Plug vector for INT 42 (port 2) into vector table using #pragma
// Non-bios interrupt uses interrupt keyword
//
// Take snapshot of Timestamp timer and then clear IFG register
//------------------------------------------------------------------
#pragma vector = 42 							// PORT2_VECTOR
interrupt void isr_nonBIOS (void)
{
	nonbios_isr_end = Timestamp_get32();		// Take snapshot of timer

	P2IFG = 0;									// clear P2IFG register
}



//----------------------------------------------------------------------
// main()
//
// Call hardware_init() to perform hardware setup for this architecture
// Then call BIOS_start()
// Note:  as soon as BIOS_start() begins, it will run the taskFxn above
//----------------------------------------------------------------------
void main(void) {

	hardware_init();	// target-specific hardware setup

	BIOS_start();    	// does not return
}



//------------------------------------------------------------------------
// hardware_init()
//
// perform any hardware init functions required for interrupts, memory,
// watchdog, etc. for this specific architecture.
//------------------------------------------------------------------------
void hardware_init(void) {

	WDT_A_hold(WDT_A_BASE);								// stop watchdog timer

	GPIO_enableInterrupt ( GPIO_PORT_P1, GPIO_PIN1 );	// enable GPIO port 1 and 2 interrupts
	GPIO_enableInterrupt ( GPIO_PORT_P2, GPIO_PIN1 );

}



