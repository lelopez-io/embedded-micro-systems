//-----------------------------------------------------------------------------
// Project: Blink LED on C6748 EVM
//
// Author: Eric Wilbur (Aug 2013)
//
// Note:  the USTIMER_delay() function in this file is NOT BIOS compatible
//        It uses two timers and steps on BIOS' clock fxns and Timestamp
//        We are not using these in this lab, so it is a don't care. But user
//        beware.  ;-)
//
//-----------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  								//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 						//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>


//-----------------------------------------------------------------------------
// Header Files (LogicPD Board Support Library header files)
//-----------------------------------------------------------------------------
#define TYPES_H										//needed due to conflict with BSL types.h

#include "stdio.h"
#include "string.h"
#include "types.h"
#include "evmomapl138.h"
#include "evmomapl138_gpio.h"
#include "evmomapl138_i2c.h"
#include "evmomapl138_led.h"
#include "evmomapl138_timer.h"


//-------------------------------------------------------
// PROTOTYPES
//-------------------------------------------------------
void hardware_init(void);
void ledToggle (void);
void delay (void);


//-------------------------------------------------------
// Globals
//-------------------------------------------------------
volatile int16_t i16ToggleCount = 0;


//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();

}


//-----------------------------------------------------------------------------
// hardware_init()
//-----------------------------------------------------------------------------
void hardware_init(void)					//called by main
{
  	I2C_init(I2C0, I2C_CLK_400K);			// init I2C channel - BSL
    USTIMER_init();							// init Timer module - BSL
	LED_init();								// init LED BSL
}


//-----------------------------------------------------------------------------
// ledToggle()
//-----------------------------------------------------------------------------
void ledToggle(void)						//called by main
{
	LED_toggle(LED_1);						//toggle LED_1 on C6748 EVM

	delay();								// create a delay of ~1/2sec

	i16ToggleCount += 1;					// keep track of #toggles

	Log_info1("LED TOGGLED [%u] times", i16ToggleCount);

}


//-----------------------------------------------------------------------------
// delay()
//-----------------------------------------------------------------------------
void delay(void)							//called by main
{
	USTIMER_delay(DELAY_1_SEC/2);			//delay 1/2 second
}

