//-----------------------------------------------------------------------------
// Project: Blink LED on C6748 EVM Using Task, Sem, Mailbox and Queue (SOLUTION)
//
// Author: Eric Wilbur (Oct 2013)
//
// Note:  the USTIMER_init routine from Logic PD's BSL initializes two timers -
//        Timer 0 and Timer 1. We overwrite the Timer0(3:4) values for the
//        timer used in this lab. USTIMER_init() should NOT be used in BIOS
//        programs because it conflicts with BIOS timers for Clock and
//        Timestamp. However, the I2C_init() routine calls USTIMER_delay()
//        which needs USTIMER_init(). Oh boy. Solution? The author wrote a
//        BIOS compatible USTIMER_delay() fxn (at the bottom) that is used by
//        the BSL calls internally. And all is well...
//-----------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>				//needed for any Log_info() call
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles
#include <xdc/runtime/Timestamp.h> 			//when using Timestamp APIs (TSCL/H), 32bit, 64bit


//-----------------------------------------------------------------------------
// Header Files (LogicPD Board Support Library header files)
//-----------------------------------------------------------------------------
#define TYPES_H								//needed due to conflict with BSL types.h

//#include "stdio.h"
//#include "string.h"
#include "types.h"
#include "evmomapl138.h"
#include "evmomapl138_gpio.h"
#include "evmomapl138_i2c.h"
#include "evmomapl138_led.h"
#include "evmomapl138_timer.h"


//-------------------------------------------------------
// PROTOTYPES
//-------------------------------------------------------
void hardware_init(void);
void ledToggle (void);
void mailbox_queue(void);
void Timer_ISR(void);


//-------------------------------------------------------
// Globals
//-------------------------------------------------------
volatile int16_t i16ToggleCount = 0;

//------------------------
// for Mailbox - Part A
//------------------------
//typedef struct MsgObj {
//	Int	val;            	/* message value */
//} MsgObj, *Msg;


//------------------------
// for Queue - Part B
//------------------------
typedef struct MsgObj {
	Queue_Elem	elem;
	Int	val;            	/* message value */
} MsgObj, *Msg;				/* Use Msg as pointer to MsgObj */



//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();

}


//-----------------------------------------------------------------------------
// hardware_init()
//-----------------------------------------------------------------------------
void hardware_init(void)						//called by main
{
  	I2C_init(I2C0, I2C_CLK_400K);				// init I2C channel - BSL
	LED_init();									// init LED BSL

// Timer_0 3:4 setup code using BSL

    TMR0->GPINT_GPEN = GPENO12 | GPENI12;		// enable muxed pins as GPIO outputs and
    TMR0->GPDATA_GPDIR = GPDIRO12 | GPDIRI12;	// disable all related interrupts

    TMR0->TGCR = 0x00000000;					// stop and reset timer 0
    TMR0->TCR = 0x00000000;

// config timer0 in 32-bit unchained mode, remove timer0 (3:4) from reset
    SETBIT(TMR0->TGCR, PRESCALER(1) | TIMMODE_32BIT_UNCHAINED | TIM34RS );

// config timer 0 3:4 timer and period registers 0x
    TMR0->TIM34 = 0x00000000;
    TMR0->PRD34 = 0x500000;

    SETBIT(TMR0->TCR, ENAMODE34_CONT);			// start timer0 3:4, continuous mode

}


//---------------------------------------------------------------------------
// mailbox_queue Task() - Run by BIOS_Start(), then unblocked by Timer ISR
//
// Places state of LED (msg.val) into a mailbox for ledToggle() to use
//---------------------------------------------------------------------------
void mailbox_queue(void)
{

//---------------------------------
// msg used for Mailbox and Queue
//---------------------------------
	MsgObj msg;													// create an instance of MsgObj named msg

//---------------------------------
// msgp used for Queue only
//---------------------------------
	Msg msgp;													// Queues pass POINTERS, so we need a pointer of type Msg
	msgp = &msg;												// init message pointer to address of msg


	msg.val = 1;												// set initial value of msg.val (LED state)

	while(1){

		msg.val ^= 1;											// toggle msg.val (LED state)

		Semaphore_pend(mailbox_queue_sem, BIOS_WAIT_FOREVER);	// wait on semaphore from Timer ISR

//------------------------------
// MAILBOX CODE follows...
//------------------------------
//		Mailbox_post (LED_Mbx, &msg, BIOS_WAIT_FOREVER);		// post msg containing LED state into the MAILBOX


//------------------------------
// QUEUE CODE follows...
//------------------------------
		Queue_put(LED_Queue, (Queue_Elem*)msgp);				// pass pointer to Message object via LED_Queue
		Semaphore_post (QueSem);								// unblock Queue_get to get msg

	}

}


//-----------------------------------------------------------------------------
// ledToggle()  - called by BIOS_Start(), then unblocked by mailbox_queue()
//-----------------------------------------------------------------------------
void ledToggle(void)						//called by main
{

//---------------------------------
// msg used for Mailbox and Queue
//---------------------------------
	MsgObj msg;													//define msg using MsgObj struct created earlier

//---------------------------------
// msgp used for Queue only
//---------------------------------
	Msg msgp;													//define pointer to MsgObj to use with queue put/get
	msgp = &msg;												//init msgp to point to address of msg (used for put/get)


	while(1)
	{

//------------------------------
// MAILBOX CODE follows...
//------------------------------
//		Mailbox_pend(LED_Mbx, &msg, BIOS_WAIT_FOREVER);			// wait/block until post of msg, get msg.val


//------------------------------
// QUEUE CODE follows...
//------------------------------
		Semaphore_pend(QueSem, BIOS_WAIT_FOREVER);				// unblocked by mailbox_queue() when Queue has msg
		msgp = Queue_get(LED_Queue);							// read contents of queue to get value of LED state


//		if (msg.val)											// MAILBOX "if" - msg.val contains LED state

		if(msgp->val)											// QUEUE "if" - mspg->val contains LED state for QUEUE's the use pointers
		{
			LED_turnOn(LED_1);									// Turn LED ON
		}
		else
		{
			LED_turnOff(LED_1);									// Turn LED OFF
		}


		i16ToggleCount += 1;					// keep track of #toggles

		Log_info1("LED TOGGLED [%u] times", i16ToggleCount);
	}
}


//---------------------------------------------------------------------------
// Timer_ISR()
//
// Called by Hwi when timer hits zero
//---------------------------------------------------------------------------
void Timer_ISR(void)
{
	Semaphore_post(mailbox_queue_sem);
}


//-----------------------------------------------------------------------------
// USTIMER_delay()
//
// LogicPD BSL fxn - re-written for a few BSL.c files that need it.
// The original USTIMER_init() is not used because it is NOT BIOS compatible
// and took both timers so that BIOS PRDs would not work. This is a
// workaround.
//
// If you need a "delay" in this app, call this routine with the number
// of usec's of delay you need. It is approximate - not exact.
// value for time<300 is perfect for 1us. We padded it some.
//-----------------------------------------------------------------------------
void USTIMER_delay(uint32_t usec)
{
	volatile int32_t i, start, time, current;

	for (i=0; i<usec; i++)
	{
		start = Timestamp_get32();
		time = 0;
		while (time < 350)
		{
			current = Timestamp_get32();
			time = current - start;
		}
	}
}


