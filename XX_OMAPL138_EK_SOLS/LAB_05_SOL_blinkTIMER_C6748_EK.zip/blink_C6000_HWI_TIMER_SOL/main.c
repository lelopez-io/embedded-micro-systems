//-----------------------------------------------------------------------------
// Project: Blink LED on C6748 EVM Using BIOS Timer (SOLUTION)
//
// Author: Eric Wilbur (Aug 2013)
//
// Note:  the USTIMER_init routine from Logic PD's BSL initializes two timers -
//        Timer 0 and Timer 1. We overwrite the Timer0(3:4) values for the
//        timer used in this lab. USTIMER_init() should NOT be used in BIOS
//        programs because it conflicts with BIOS timers for Clock and
//        Timestamp. However, the I2C_init() routine calls USTIMER_delay()
//        which needs USTIMER_init(). Oh boy. Solution? The author wrote a
//        BIOS compatible USTIMER_delay() fxn (at the bottom) that is used by
//        the BSL calls internally. And all is well...
//-----------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>				//needed for any Log_info() call
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles
#include <xdc/runtime/Timestamp.h> 			//when using Timestamp APIs (TSCL/H), 32bit, 64bit


//-----------------------------------------------------------------------------
// Header Files (LogicPD Board Support Library header files)
//-----------------------------------------------------------------------------
#define TYPES_H								//needed due to conflict with BSL types.h

#include "stdio.h"
#include "string.h"
#include "types.h"
#include "evmomapl138.h"
#include "evmomapl138_gpio.h"
#include "evmomapl138_i2c.h"
#include "evmomapl138_led.h"
#include "evmomapl138_timer.h"


//-------------------------------------------------------
// PROTOTYPES
//-------------------------------------------------------
void hardware_init(void);
void ledToggle (void);


//-------------------------------------------------------
// Globals
//-------------------------------------------------------
volatile int16_t i16ToggleCount = 0;


//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();

}


//-----------------------------------------------------------------------------
// hardware_init()
//-----------------------------------------------------------------------------
void hardware_init(void)						//called by main
{
  	I2C_init(I2C0, I2C_CLK_400K);				// init I2C channel - BSL
 	LED_init();									// init LED BSL

/* BIOS Timer used in this lab - no need for Timer setup code any longer
// Timer_0 3:4 setup code using BSL

    TMR0->GPINT_GPEN = GPENO12 | GPENI12;		// enable muxed pins as GPIO outputs and
    TMR0->GPDATA_GPDIR = GPDIRO12 | GPDIRI12;	// disable all related interrupts

    TMR0->TGCR = 0x00000000;					// stop and reset timer
    TMR0->TCR = 0x00000000;

// config timer0 in 32-bit unchained mode, remove timer0 (3:4) from reset
    SETBIT(TMR0->TGCR, PRESCALER(1) | TIMMODE_32BIT_UNCHAINED | TIM34RS );

// config timer 0 3:4 timer and period registers 0x
    TMR0->TIM34 = 0x00000000;
    TMR0->PRD34 = 0x0f0000;

    SETBIT(TMR0->TCR, ENAMODE34_CONT);			// start timer0 3:4, continuous mode

*/
}


//-----------------------------------------------------------------------------
// ledToggle() ISR (called by BIOS Hwi, see app.cfg)
//-----------------------------------------------------------------------------
void ledToggle(void)						//called by main
{
	LED_toggle(LED_1);						//toggle LED_1 on C6748 EVM

	i16ToggleCount += 1;					// keep track of #toggles

	Log_info1("LED TOGGLED [%u] times", i16ToggleCount);

}


//-----------------------------------------------------------------------------
// USTIMER_delay()
//
// LogicPD BSL fxn - re-written for a few BSL.c files that need it.
// The original USTIMER_init() is not used because it is NOT BIOS compatible
// and took both timers so that BIOS PRDs would not work. This is a
// workaround.
//
// If you need a "delay" in this app, call this routine with the number
// of usec's of delay you need. It is approximate - not exact.
// value for time<300 is perfect for 1us. We padded it some.
//-----------------------------------------------------------------------------
void USTIMER_delay(uint32_t usec)
{
	volatile int32_t i, start, time, current;

	for (i=0; i<usec; i++)
	{
		start = Timestamp_get32();
		time = 0;
		while (time < 350)
		{
			current = Timestamp_get32();
			time = current - start;
		}
	}
}

