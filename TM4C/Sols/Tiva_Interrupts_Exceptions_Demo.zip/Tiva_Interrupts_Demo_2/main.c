//---------------------------------------------------------------------------
// Project: Blink TM4C BIOS
// Author: Eric Wilbur
// Date: Aug 2013
//---------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles
#include <xdc/runtime/Log.h>				//used for Log_info() calls

#include <xdc/runtime/System.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>

#include <ti/sysbios/family/arm/m3/Hwi.h>

#include <string.h>

#include <xdc/runtime/Error.h>


//------------------------------------------
// TivaWare Header Files
//------------------------------------------
#include <stdint.h>
#include <stdbool.h>

#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include <time.h>


//----------------------------------------
// Prototypes
//----------------------------------------
void hardware_init(void);
void ledToggle(void);
void delay(void);
void isr50(UArg a0);
void isr51(UArg unused);
Void copyVal(Char *dst, Char *src);
void exception_test(void);
void interrupt_test(void);


//---------------------------------------
// Globals
//---------------------------------------
volatile int16_t i16ToggleCount = 0;
UInt32 t0, t1, t2, t3;
UInt32 overhead;
UInt32 delta50a, delta51a, delta50b, delta51b;
Types_FreqHz freq;


//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();

}


//---------------------------------------------------------------------------
// hardware_init()
//
// inits GPIO pins for toggling the LED
//---------------------------------------------------------------------------
void hardware_init(void)
{
	//Set CPU Clock to 40MHz. 400MHz PLL/2 = 200 DIV 5 = 40MHz
	SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|SYSCTL_OSC_MAIN);

	// ADD Tiva-C GPIO setup - enables port, sets pins 1-3 (RGB) pins for output
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3);

	// Turn on the LED
	GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, 4);

}


//---------------------------------------------------------------------------
// ledToggle()
//
// toggles LED on Tiva-C LaunchPad
//---------------------------------------------------------------------------
void ledToggle(void)
{
	// LED values - 2=RED, 4=BLUE, 8=GREEN
	if(GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_2))
	{
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, 0);
	}
	else
	{
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 4);
	}

	delay();								// create a delay of ~1/2sec

	i16ToggleCount += 1;					// keep track of #toggles

	Log_info1("LED TOGGLED [%u] TIMES",i16ToggleCount);

}



//---------------------------------------------------------------------------
// delay()
//
// Creates a 500ms delay via TivaWare fxn
//---------------------------------------------------------------------------
void delay(void)
{
	 SysCtlDelay(5000000);		// creates ~500ms delay - TivaWare fxn

}



////////////////////////////////////////////////////////////////////////////
/////////////////////  EXCEPTION TEST  /////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------------------
// exception_test() TASK
//
// Test exception output for Tiva-C
//---------------------------------------------------------------------------
void exception_test(void)
{

/*    char buf[2048];
    memset(buf, 0, 128);

    char *buf0 = (char *)0x10000000;    //illegal address
    char *buf1 = (char *)0x20000000;

    copyVal(buf1, buf1);

    copyVal(buf1, buf0);

    copyVal(buf0, buf0);*/
}

/*
 *  ======== copyVal ========
 */
Void copyVal(Char *dst, Char *src)
{
	*dst = *src;
}


////////////////////////////////////////////////////////////////////////////
////////////////////////  INTERRUPT TEST  //////////////////////////////////
////////////////////////////////////////////////////////////////////////////


//---------------------------------------------------------------------------
// interrupt_test() TASK
//
// Test timing of Tiva Interrupts - BIOS vs. Zero Latency
//---------------------------------------------------------------------------
void interrupt_test(void)
{

	Hwi_Params hwiParams;
	UInt key;
	volatile Int delay;

	Timestamp_getFreq(&freq);

	t0 = Timestamp_get32();
	t1 = Timestamp_get32();
	overhead = t1 - t0;

	/* Create a Hwi with default parameters.  This Hwi will use the Hwi dispatcher */
	Hwi_create(50, isr50, NULL, NULL);

	/*
	 * Create a zero-latency Hwi by specifying priority = 0 (highest)
     * This interrupt will never be disabled by BIOS since our default
     * high water mark is set to priority 1 (second to highest).
     */
	Hwi_Params_init(&hwiParams);
	hwiParams.priority = 0;
	Hwi_create(51, isr51, &hwiParams, NULL);

	/* do some benchmarks with interrupts enabled */

	t0 = Timestamp_get32();
	Hwi_post(50);

	t2 = Timestamp_get32();
	Hwi_post(51);

	delta50a = t1 - t0 - overhead;
	delta51a = t3 - t2 - overhead;

	/* do benchmarks again with interrupts disabled */

	key = Hwi_disable();

	t0 = Timestamp_get32();
	Hwi_post(50);

	t2 = Timestamp_get32();
	Hwi_post(51);

	for (delay = 0; delay < 10000; delay++) {
	}

	Hwi_restore(key);

	delta50b = t1 - t0 - overhead;
	delta51b = t3 - t2 - overhead;

	System_printf("delta50a = %d\n", delta50a);
	System_printf("delta51a = %d\n", delta51a);
	System_printf("delta50b = %d\n", delta50b);
	System_printf("delta51b = %d\n", delta51b);
	System_flush();
}



/*
 * ======== isr50 ========
 * normal Hwi-dispach()'d ISR
 */
Void isr50(UArg a0)
{
	t1 = Timestamp_get32();
}

/*
 * ======== isr51 ========
 * zero-latency ISR with no interaction with BIOS
 */
Void isr51(UArg unused)
{
	t3 = Timestamp_get32();
}



