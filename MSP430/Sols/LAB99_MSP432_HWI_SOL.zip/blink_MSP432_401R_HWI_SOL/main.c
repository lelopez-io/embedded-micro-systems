//----------------------------------------------------------------------------------
// Project: Blink MSP432P401R_LP using BIOS Hwi (SOLUTION)
// Author: Eric Wilbur
// Date: March 2015
//
// Follow these steps to create this project in CCSv6.0:
// 1. Project -> New CCS Project
// 2. Select Template:
//    - TI-RTOS for MSP430 -> Driver Examples -> MSP-EXP432P401R -> Example Projects ->
//      Empty Project
//    - Empty Project contains full instrumentation (UIA, RTOS Analyzer) and
//      paths set up for the TI-RTOS version of MSP430Ware
// 3. Delete the following files:
//    - Board.h, empty.c, MSP432.c/h, empty_readme.txt
// 4. Add main.c from TI-RTOS Workshop Solution file for this lab
// 5. Edit empty.cfg as needed (to add/subtract) BIOS services, delete Task
// 6. Build, load, run...
//----------------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>				//needed for any Log_info() call
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles


//-----------------------------------------
// MSP430 Header Files
//-----------------------------------------
#include <driverlib.h>
#include <msp432p401r.h>					//needed to help users find the interrupt number for Timer A1


//-----------------------------------------
// Prototypes
//-----------------------------------------
void hardware_init(void);
void ledToggle(void);


//-----------------------------------------
// Globals
//-----------------------------------------
volatile int16_t i16ToggleCount = 0;

// Setup TimerA1 in Up mode using ACLK, timer INT every 1/2 second
Timer_A_UpModeConfig initUpParam =
{   TIMER_A_CLOCKSOURCE_ACLK,                 	// Use ACLK (slower clock)
    TIMER_A_CLOCKSOURCE_DIVIDER_1,          	// Input clock = ACLK / 1 = 32KHz
    0x4000,                                    	// Period (0xFFFF/4):  4000 / 32Khz = 1/2 second
    TIMER_A_TAIE_INTERRUPT_DISABLE,    			// Enable TAR -> 0 interrupt
    TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE,       	// Enable CCR0 compare interrupt
    TIMER_A_DO_CLEAR,                        	// Clear TAR & clock divider
};



//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();

}


//-----------------------------------------------------------------------------
// hardware_init() - for FR5969 Launchpad
//-----------------------------------------------------------------------------
void hardware_init(void)					//called by main
{
	// Disable the Watchdog Timer (important, as this is enabled by default)
	WDT_A_holdTimer();

	// INIT GPIO

    	// Set pin P1.0 to output direction and turn LED off
    	GPIO_setAsOutputPin( GPIO_PORT_P1, GPIO_PIN0 );                   // Red LED (LED1)
    	GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );

    	// GPIO_setAsOutputPin( GPIO_PORT_P2, GPIO_PIN1 );                // Green P2.1, Blue P2.2 (if desired)
    	// GPIO_setOutputLowOnPin( GPIO_PORT_P2, GPIO_PIN1 );

    // INIT CLOCKS

        // Select LFXT as ACLK source  (32KHz) - Clk cfg (ACLK), Clk src (REFO), div down (1)
        CS_initClockSignal( CS_ACLK, CS_REFOCLK_SELECT, CS_CLOCK_DIVIDER_1 );

        // Select MODOSC as SMCLK source - (12MHz) - Clk cfg (SMCLK), Clk src (MODOSC), div down (1)
        CS_initClockSignal( CS_SMCLK, CS_MODOSC_SELECT, CS_CLOCK_DIVIDER_2 );

        // Set the MCLK to use the MODOSC clock - (12MHz)
        CS_initClockSignal( CS_MCLK, CS_MODOSC_SELECT, CS_CLOCK_DIVIDER_2 );

    // INIT TIMER A1

        Timer_A_configureUpMode( TIMER_A1_BASE, &initUpParam );              	// Set up Timer A1

        // Clear/enable flags and start timer
        Timer_A_clearCaptureCompareInterrupt( TIMER_A1_BASE,
            TIMER_A_CAPTURECOMPARE_REGISTER_0 );                           		// Clear CCR0IFG

        Timer_A_startCounter( TIMER_A1_BASE, TIMER_A_UP_MODE);					// Start Timer A1

}


//-------------------------------------------------------------------------------
// ledToggle() ISR
//
// Toggle LED 1 (red) via GPIO pin
// Use (GPIO_PORT_P2, GPIO_PIN1 ) to toggle green LED2 (P2.2 - blue) if desired
//-------------------------------------------------------------------------------
void ledToggle(void)
{
    Timer_A_clearCaptureCompareInterrupt( TIMER_A1_BASE,
        TIMER_A_CAPTURECOMPARE_REGISTER_0 );                // Clear CCR0IFG - Cortex M4F requirement

	GPIO_toggleOutputOnPin( GPIO_PORT_P1, GPIO_PIN0 );		// toggle Port1 Pin0 (red LED), P2.1 (green), P2.2 (blue)

	i16ToggleCount += 1;									// keep track of #toggles

	Log_info1("LED TOGGLED [%u] TIMES", i16ToggleCount);	// send results to log display

}


