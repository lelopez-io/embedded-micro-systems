//----------------------------------------------------------------------------------
// Project: Blink MSP430-FR5969 using BIOS Hwi (SOLUTION)
// Author: Eric Wilbur
// Date: March 2015
//
// Follow these steps to create this project in CCSv6.0:
// 1. Project -> New CCS Project
// 2. Select Template:
//    - TI-RTOS for MSP430 -> Driver Examples -> FR5969 LP -> Example Projects ->
//      Empty Project
//    - Empty Project contains full instrumentation (UIA, RTOS Analyzer) and
//      paths set up for the TI-RTOS version of MSP430Ware
// 3. Delete the following files:
//    - Board.h, empty.c, MSP_EXP430FR5969LP.c/h, empty_readme.txt
// 4. Add main.c from TI-RTOS Workshop Solution file for this lab
// 5. Edit empty.cfg as needed (to add/subtract) BIOS services, delete Task
// 6. Build, load, run...
//----------------------------------------------------------------------------------


//----------------------------------------
// BIOS header files
//----------------------------------------
#include <xdc/std.h>  						//mandatory - have to include first, for BIOS types
#include <ti/sysbios/BIOS.h> 				//mandatory - if you call APIs like BIOS_start()
#include <xdc/runtime/Log.h>				//needed for any Log_info() call
#include <xdc/cfg/global.h> 				//header file for statically defined objects/handles


//-----------------------------------------
// MSP430 Header Files
//-----------------------------------------
#include <driverlib.h>
#include <msp430fr5969.h>					//not needed - but used to find interrupt vector number (line 4550)



//-----------------------------------------
// Prototypes
//-----------------------------------------
void hardware_init(void);
void ledToggle(void);


//-----------------------------------------
// Globals
//-----------------------------------------
volatile int16_t i16ToggleCount = 0;

// Setup TimerA1 in Up mode using ACLK, timer INT every 1/2 second
Timer_A_initUpModeParam initUpParam =
{   TIMER_A_CLOCKSOURCE_ACLK,                 	// Use ACLK (slower clock)
    TIMER_A_CLOCKSOURCE_DIVIDER_1,          	// Input clock = ACLK / 1 = 32KHz
    0x4000,                                    	// Period (0xFFFF/4):  4000 / 32Khz = 1/2 second
    TIMER_A_TAIE_INTERRUPT_DISABLE,    			// Enable TAR -> 0 interrupt
    TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE,       	// Enable CCR0 compare interrupt
    TIMER_A_DO_CLEAR,                        	// Clear TAR & clock divider
    1											// start timer immediately
};


//---------------------------------------------------------------------------
// main()
//---------------------------------------------------------------------------
void main(void)
{

   hardware_init();							// init hardware via Xware

   BIOS_start();

}


//-----------------------------------------------------------------------------
// hardware_init() - for FR5969 Launchpad
//-----------------------------------------------------------------------------
void hardware_init(void)					//called by main
{
	// Disable the Watchdog Timer (important, as this is enabled by default)
	WDT_A_hold( WDT_A_BASE );

	// INIT GPIO

    	// Set pin P1.0 to output direction and turn LED off
    	GPIO_setAsOutputPin( GPIO_PORT_P1, GPIO_PIN0 );                   // Green LED (LED2)
    	GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );

    	// GPIO_setAsOutputPin( GPIO_PORT_P4, GPIO_PIN6 );                // Use for Red LED (LED1) if desired
    	// GPIO_setOutputLowOnPin( GPIO_PORT_P4, GPIO_PIN6 );

    	// Unlock pins (required for FRAM devices)
    	// Unless waking from LPMx.5, this should be done before clearing and enabling GPIO port interrupts
    	PMM_unlockLPM5();

        // Set LFXT (low freq crystal pins) to crystal input (rather than GPIO) - tie ext'l crystal to pins for ACLK
        GPIO_setAsPeripheralModuleFunctionInputPin( GPIO_PORT_PJ, GPIO_PIN4 + GPIO_PIN5 , GPIO_PRIMARY_MODULE_FUNCTION );

    // INIT CLOCKS

        // Initialize LFXT crystal oscillator without a timeout
        CS_turnOnLFXT( CS_LFXT_DRIVE_0 );

        // Set DCO to 8MHz - Set freq range (DCOR) and frequency (DCOF)
        CS_setDCOFreq( CS_DCORSEL_1, CS_DCOFSEL_3 );

        // Select LFXT as ACLK source  (32KHz) - Clk cfg (ACLK), Clk src (LFXTCLK), div down (1)
        CS_initClockSignal( CS_ACLK, CS_LFXTCLK_SELECT, CS_CLOCK_DIVIDER_1 );

        // Select DCO as SMCLK source - (8MHz) - Clk cfg (SMCLK), Clk src (DCO), div down (1)
        CS_initClockSignal( CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1 );

        // Set the MCLK to use the DCO clock (configured earlier in this routine) (8MHz)
        CS_initClockSignal( CS_MCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1 );

    // INIT TIMER A1

        Timer_A_initUpMode( TIMER_A1_BASE, &initUpParam );              	// Set up Timer A1

        // Clear/enable flags and start timer
        Timer_A_clearCaptureCompareInterrupt( TIMER_A1_BASE,
            TIMER_A_CAPTURECOMPARE_REGISTER_0 );                           	// Clear CCR0IFG

}


//---------------------------------------------------------------------------
// ledToggle() ISR
//
// Toggle LED 2 (green) via GPIO pin
// Use (GPIO_PORT_P4, GPIO_PIN6 ) to toggle red LED if desired
//---------------------------------------------------------------------------
void ledToggle(void)
{
	GPIO_toggleOutputOnPin( GPIO_PORT_P1, GPIO_PIN0 );		// toggle Port1 Pin0 (green LED), use P4/PIN6 for red LED

	i16ToggleCount += 1;									// keep track of #toggles

	Log_info1("LED TOGGLED [%u] TIMES", i16ToggleCount);	// send results to log display

}


